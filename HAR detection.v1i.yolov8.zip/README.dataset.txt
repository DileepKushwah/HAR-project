# HAR detection > 2024-12-27 11:32pm
https://universe.roboflow.com/har-project-viijb/har-detection

Provided by a Roboflow user
License: CC BY 4.0

